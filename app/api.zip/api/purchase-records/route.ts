// ============================================
// app/api/purchase-records/route.ts【修正版】
// ============================================

import {
  createPurchaseRecord,
  PurchaseRecordData,
} from '@/services/purchase-service';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as Partial<PurchaseRecordData>;

    // バリデーション
    if (
      !body.order_id ||
      !body.vehicle_name ||
      !body.auction_date ||
      body.bid_price === undefined
    ) {
      return NextResponse.json(
        { 
          success: false, 
          error: 'Missing required fields: order_id, vehicle_name, auction_date, bid_price' 
        },
        { status: 400 }
      );
    }

    const purchaseData: PurchaseRecordData = {
      order_id: body.order_id,
      desired_vehicle_id: body.desired_vehicle_id,
      sequence_number: body.sequence_number || 1,
      vehicle_name: body.vehicle_name,
      maker: body.maker,
      model: body.model,
      year: body.year,
      mileage: body.mileage,
      inspection_date: body.inspection_date,
      color: body.color,
      body_color: body.body_color,
      transmission: body.transmission,
      engine: body.engine,
      chassis_number: body.chassis_number,
      registration_number: body.registration_number,
      auction_date: body.auction_date,
      bid_price: body.bid_price,
      bid_date: body.bid_date,
      tax_amount: body.tax_amount || 0, // 【新規】自動車税
      bid_fee: body.bid_fee || 0, // 【新規】成約落札料
      status: body.status,
      variance_reason: body.variance_reason,
      notes: body.notes,
    };

    const recordId = await createPurchaseRecord(purchaseData);

    // 計算結果を返す
    const totalPrice = body.bid_price + (body.tax_amount || 0) + (body.bid_fee || 0);

    return NextResponse.json(
      { 
        success: true, 
        data: { 
          id: recordId,
          total_purchase_price: totalPrice,
          message: '仕入実績が登録されました'
        } 
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('POST /api/purchase-records:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create purchase record' },
      { status: 500 }
    );
  }
}

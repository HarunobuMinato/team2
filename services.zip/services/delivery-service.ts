import { getConnection } from '@/lib/api-client';
import { RowDataPacket, OkPacket } from 'mysql2';

export interface DeliveryData {
  delivery_number: string;
  order_id: number;
  client_id: number;
  delivery_date: string;
  purchase_record_ids: number[];
  vehicle_count: number;
  vehicle_price: number;
  commission: number;
  tax: number;
  total_amount: number;
  status?: string;
  notes?: string;
}

export interface DeliveryResponse extends RowDataPacket {
  id: number;
  delivery_number: string;
  order_id: number;
  client_id: number;
  delivery_date: string;
  purchase_record_ids: string;  // JSON文字列
  vehicle_count: number;
  vehicle_price: number;
  commission: number;
  tax: number;
  total_amount: number;
  status: string;
  created_at: Date;
  updated_at: Date;
}

/**
 * 納品書を作成
 */
export async function createDelivery(data: DeliveryData): Promise<number> {
  const connection = await getConnection();

  try {
    const sql = `
      INSERT INTO deliveries (
        delivery_number, order_id, client_id, delivery_date,
        purchase_record_ids, vehicle_count,
        vehicle_price, commission, tax, total_amount,
        status, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const [result] = await connection.execute<OkPacket>(sql, [
      data.delivery_number,
      data.order_id,
      data.client_id,
      data.delivery_date,
      JSON.stringify(data.purchase_record_ids),
      data.vehicle_count,
      data.vehicle_price,
      data.commission,
      data.tax,
      data.total_amount,
      data.status || 'draft',
      data.notes || null,
    ]);

    return result.insertId;
  } finally {
    connection.release();
  }
}

/**
 * 納品書を取得
 */
export async function getDelivery(deliveryId: number): Promise<DeliveryResponse | null> {
  const connection = await getConnection();

  try {
    const sql = 'SELECT * FROM deliveries WHERE id = ? AND is_deleted = false';
    const [rows] = await connection.execute<DeliveryResponse[]>(sql, [deliveryId]);
    return rows.length > 0 ? rows[0] : null;
  } finally {
    connection.release();
  }
}

/**
 * 納品書一覧を取得
 */
export async function getDeliveries(
  clientId?: number,
  status?: string,
  limit: number = 20,
  offset: number = 0
): Promise<DeliveryResponse[]> {
  const connection = await getConnection();

  try {
    let sql = 'SELECT * FROM deliveries WHERE is_deleted = false';
    const params: any[] = [];

    if (clientId) {
      sql += ' AND client_id = ?';
      params.push(clientId);
    }

    if (status) {
      sql += ' AND status = ?';
      params.push(status);
    }

    sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const [rows] = await connection.execute<DeliveryResponse[]>(sql, params);
    return rows;
  } finally {
    connection.release();
  }
}

/**
 * 納品書を更新
 */
export async function updateDelivery(
  deliveryId: number,
  data: Partial<DeliveryData>
): Promise<boolean> {
  const connection = await getConnection();

  try {
    const updates: string[] = [];
    const params: any[] = [];

    if (data.status) {
      updates.push('status = ?');
      params.push(data.status);
    }
    if (data.notes !== undefined) {
      updates.push('notes = ?');
      params.push(data.notes);
    }

    updates.push('updated_at = CURRENT_TIMESTAMP');
    params.push(deliveryId);

    const sql = `
      UPDATE deliveries SET ${updates.join(', ')} WHERE id = ?
    `;

    const [result] = await connection.execute<OkPacket>(sql, params);
    return result.affectedRows > 0;
  } finally {
    connection.release();
  }
}